#!/usr/bin/env python3
"""Lab access layer: the ONLY thing the future agent touches.
Read-only by design. Run: python tools/lab_cli.py hq-edge "show bgp summary"
"""
import subprocess, sys

LAB = "clab-wanlab"
ROUTERS = ["hq-edge", "dc-edge", "br1-edge", "br2-edge", "isp1", "isp2"]
HOSTS = ["hq-host", "dc-host", "br1-host", "br2-host"]

def _run(argv, timeout=15):
    p = subprocess.run(argv, capture_output=True, text=True, timeout=timeout)
    out = (p.stdout + p.stderr).strip()
    noise = ("vtysh.conf", "processing failure")
    return "\n".join(l for l in out.splitlines() if not any(n in l for n in noise))

def show(node: str, command: str) -> str:
    """Run a read-only FRR 'show' command on a router."""
    if node not in ROUTERS:
        return f"ERROR: unknown router '{node}'. Valid: {ROUTERS}"
    if not command.strip().startswith("show ") or any(c in command for c in ";|&`$"):
        return "ERROR: only plain 'show ...' commands are allowed"
    return _run(["docker", "exec", f"{LAB}-{node}", "vtysh", "-c", command])

def ping(host: str, target: str, count: int = 3) -> str:
    """Ping from a lab host to an IP address."""
    if host not in HOSTS:
        return f"ERROR: unknown host '{host}'. Valid: {HOSTS}"
    if not target.replace(".", "").isdigit():
        return "ERROR: target must be an IPv4 address"
    return _run(["docker", "exec", f"{LAB}-{host}", "ping", "-c", str(count), "-W", "1", target])

def traceroute(host: str, target: str) -> str:
    if host not in HOSTS or not target.replace(".", "").isdigit():
        return "ERROR: bad host or target"
    return _run(["docker", "exec", f"{LAB}-{host}", "traceroute", "-n", "-w", "1", target], timeout=30)

def linkstats(node: str, iface: str) -> str:
    """Read-only kernel-level link state: interface counters + any traffic shaping (netem/tc).
    Covers faults invisible to 'show' (which only sees FRR/vtysh, not the Linux kernel)."""
    if node not in ROUTERS:
        return f"ERROR: unknown router '{node}'. Valid: {ROUTERS}"
    if not (iface.startswith("eth") and iface[3:].isdigit()):
        return "ERROR: iface must look like 'eth1'"
    link = _run(["docker", "exec", f"{LAB}-{node}", "ip", "-s", "link", "show", iface])
    qdisc = _run(["docker", "exec", f"{LAB}-{node}", "tc", "qdisc", "show", "dev", iface])
    return f"-- ip -s link show {iface} --\n{link}\n\n-- tc qdisc show dev {iface} --\n{qdisc}"

if __name__ == "__main__":
    print(show(sys.argv[1], sys.argv[2]))